#!/bin/bash -ue
mkdir -p results/parsnp logs

parsnp       -d dummy/parsnp/assemblies       -r ref.fa       -o results/parsnp       -p 1       &> logs/parsnp.log

harvesttools       -x results/parsnp/parsnp.xmfa       -M results/parsnp/parsnp.aln       &>> logs/parsnp.log

run_gubbins.py       -p parsnp       results/parsnp/parsnp.aln       &> logs/gubbins_on_parsnp.log
