#!/bin/bash -ue
mkdir -p logs

nextflow run nf-core/bactmap       --input      $PWD/samples.csv       --reference  $PWD/ref.fa       -profile     docker       --trim --remove_recombination --iqtree       --max_memory 15.GB       --outdir     results/bactmap       &> logs/bactmap.log
