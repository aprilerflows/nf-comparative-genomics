#!/bin/bash -ue
mkdir -p results/bactmap logs
nextflow run nf-core/bactmap       --input      samples.csv       --reference  ref.fa       -profile     docker       --trim --remove_recombination --iqtree       --max_memory 15.GB       --outdir     results/bactmap       &> logs/bactmap.log
