#!/bin/bash -ue
mkdir -p logs

# 1) multi-genome alignment
parsnp       -d $PWD/assemblies       -r $PWD/ref.fa       -o parsnp_out       -p 1       &> logs/parsnp.log

# 2) convert for Gubbins
harvesttools       -x parsnp_out/parsnp.xmfa       -M parsnp_out/parsnp.aln       &>> logs/parsnp.log

# 3) recombination filtering
run_gubbins.py       -p parsnp       parsnp_out/parsnp.aln       &> logs/gubbins_on_parsnp.log

# 4) stage results
mkdir -p results/parsnp
cp -r parsnp_out/* results/parsnp/
